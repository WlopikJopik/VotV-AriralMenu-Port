# VotV-AriralMenu-Port

Port of the **Voices of the Void Debug Mode** (AriralMenu) to **VotV 0.10.0** (Unreal Engine 4.27.2).
The original was built for 0.8.1. This is a raw port: it works, but nothing new has been added yet.

> For single-player research and fun only. Don't use it to ruin other people's experience.

![menu](img/2.png)
![bypass tutorial restrictions](img/3.png)
![spawn / cheat menu / noclip](img/5.png)

> **Heads up:** this port was partly made with Claude, and I don't know where all the bugs are.
> If you find one, DM me on Discord: **@imyawn** and tell me about it.

## Features

* Console on **F2** (`Summon`, `Open`, `ToggleDebugCamera`, `Show StaticMeshes/BSP`, ...)
* Fly, disable collision (true noclip)
* Add points, "Chad mode" (large objects lose weight)
* No damage, no food draining, no sleep draining
* Time speed, game clock window
* Teleport (coordinates)
* Infinite fuel / health for the car
* ESP: names, boxes, lines, adjustable draw distance
* Object list, teleport props to the player, destroy props

## What changed in this port (0.8.1 -> 0.10.0)

* Class names: `AMainPlayer_C` -> `AmainPlayer_C`, `AMainGamemode_C` -> `AmainGamemode_C`,
  `ADaynightCycle_C` -> `AdaynightCycle_C`, `ACar1_C` -> `Acar1_witch_C`
* Field names: `hulkMode`, `noclip`, `foodDraining`, `sleepDraining`, `settingMultiplayer`,
  `daynightCycle`, `diff_fuel`, `health`
* Updated includes and the source list in `Project2.vcxproj`
* More reliable **Insert** key handling for the menu

## Building

The SDK is **not** included: it is generated from your own copy of the game.

1. Install **Visual Studio 2022** with the "Desktop development with C++" workload.
2. Generate an SDK with [Dumper-7](https://github.com/Encryqed/Dumper-7):
   run the game (0.10.0), inject `Dumper-7.dll` into `VotV-Win64-Shipping.exe`,
   and take the `CppSDK` folder from the output.
3. Copy the contents of `CppSDK` into `Project2/` so it looks like this:
   ```
   Project2/SDK/
   Project2/UnrealContainers.hpp
   Project2/UtfN.hpp
   Project2/Assertions.inl
   Project2/PropertyFixup.hpp
   Project2/NameCollisions.inl
   ```
4. Open `Project2.sln`, select **Release** and **x64**, build **Project2**.
   (A missing `Inject` project in the solution is expected; ignore it.)
5. Rename the output `Project2.dll` to `DebugMode.dll` if you use the included `InjectLA` injector.

## Usage

1. Start the game and wait for the main menu / world.
2. Inject `DebugMode.dll` into `VotV-Win64-Shipping.exe` (`InjectLA.exe`, Xenos, etc.).
3. Press **Insert** in game to open the menu.

Notes: don't use Time in tutorial levels, don't use ESP on weak PCs, and disable collision
before teleporting so you don't end up in the backrooms. Speeding up time can break saves.
Make backups of your saves.

## Credits

* **Vyollet** - original Voice of the Void Debug Mode: <https://github.com/Vyollet/Voice-of-the-Void-Debug-Mode>
* **WlopikJopik** - port to 0.10.0
* Libraries: [Dear ImGui](https://github.com/ocornut/imgui), [MinHook](https://github.com/TsudaKageyu/minhook),
  [kiero](https://github.com/Rebzzel/kiero), [Dumper-7](https://github.com/Encryqed/Dumper-7)
* Voices of the Void is made by MrDrNose. This project is unofficial and not affiliated with the game's author.

## License

GPL-3.0, same as the original project. See [LICENSE](LICENSE).
