using namespace SDK;

typedef struct _TslEntity
{
	int index;
	AActor* ActorObject;
	APawn* PawnActor;
	std::string Name;
	FVector Location;
	FVector Bounds;
}TslEntity;

class cheat_manager {
private:
	UEngine* Engine;
	UWorld* World;
	APlayerController* MyController;
	ULocalPlayer* LocalPlayer;
	UKismetSystemLibrary* KismetSystemLib;
	AGameModeBase* GameMode;
	AmainGamemode_C* MainGameMode;
	AdaynightCycle_C* Time;
	AmainPlayer_C* MyPawnPlayer;
	ULevel* Level;
	APawn* Pawn;
	Acar1_witch_C* Car;
	FVector2D Screen;
	FVector Location;
	FVector bbExtends;
	FVector Location2;
	AActor* ActorObject;
	APawn* PawnActor;
	AActor* PawnActorClass;
	std::string ActorName;
	FString CurrentWorldName;
	FString PreviousWorldName;
	
	//SDK::UFunction* state;

	//SDK::UUmg_spawnmenu_C* SpawnMenu;
	//SDK::UUmg_cheatMenu_C* CheatMenu;
	//UUserWidget* WidgetSpawnMenu;
	//UUserWidget* WidgetCheatMenu;

	AActor* Bypass;

	float sphereRadius = 1.0f;
	bool actorScan = false;
	int ActorsNum;
	int ChooseObject = 0;
	int item_previous = 0;
public:
	FVector PlayerLocation;
	float x;
	float y;
	float z;

	void cheat_thread();
	void exploits();
	void game_time(float day);
	void ESP();
	void actor_scan();
	void Cookies();
	void visiblecookies(const char* entity, float X, float Y, float Z);
	void teleportList(TslEntity entity);
	void tips();
	void bypass();
};